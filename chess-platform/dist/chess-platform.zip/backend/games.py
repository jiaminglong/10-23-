"""Server-authoritative board games: gomoku, tictactoe, xiangqi, doubeast."""
import random

# ---------------- Gomoku ----------------

GOMOKU_SIZE = 15


def new_gomoku():
    return {"board": [[0] * GOMOKU_SIZE for _ in range(GOMOKU_SIZE)], "last": None, "moves": 0}


def _gomoku_win(board, r, c, side):
    dirs = [(1, 0), (0, 1), (1, 1), (1, -1)]
    for dr, dc in dirs:
        cnt = 1
        for s in (1, -1):
            rr, cc = r + dr * s, c + dc * s
            while 0 <= rr < GOMOKU_SIZE and 0 <= cc < GOMOKU_SIZE and board[rr][cc] == side:
                cnt += 1
                rr += dr * s
                cc += dc * s
        if cnt >= 5:
            return True
    return False


def gomoku_move(state, move, side):
    try:
        r, c = int(move[0]), int(move[1])
    except Exception:
        return False, state, None
    board = state["board"]
    if not (0 <= r < GOMOKU_SIZE and 0 <= c < GOMOKU_SIZE) or board[r][c] != 0:
        return False, state, None
    board[r][c] = side
    state["last"] = [r, c]
    state["moves"] = state.get("moves", 0) + 1
    if _gomoku_win(board, r, c, side):
        return True, state, f"win:{side}"
    if state["moves"] >= GOMOKU_SIZE * GOMOKU_SIZE:
        return True, state, "draw"
    return True, state, None


_PATTERN_SCORES = [(5, 1000000), (4, 100000), (3, 8000), (2, 400), (1, 10)]


def _gomoku_score(board, side):
    score = 0
    for r in range(GOMOKU_SIZE):
        for c in range(GOMOKU_SIZE):
            if board[r][c] != side:
                continue
            for dr, dc in ((1, 0), (0, 1), (1, 1), (1, -1)):
                pr, pc = r - dr, c - dc
                if 0 <= pr < GOMOKU_SIZE and 0 <= pc < GOMOKU_SIZE and board[pr][pc] == side:
                    continue
                run = 0
                rr, cc = r, c
                while 0 <= rr < GOMOKU_SIZE and 0 <= cc < GOMOKU_SIZE and board[rr][cc] == side:
                    run += 1
                    rr += dr
                    cc += dc
                for n, s in _PATTERN_SCORES:
                    if run >= n:
                        score += s
                        break
    return score


def _gomoku_candidates(board, radius=2):
    cands = set()
    for r in range(GOMOKU_SIZE):
        for c in range(GOMOKU_SIZE):
            if board[r][c] != 0:
                for dr in range(-radius, radius + 1):
                    for dc in range(-radius, radius + 1):
                        rr, cc = r + dr, c + dc
                        if 0 <= rr < GOMOKU_SIZE and 0 <= cc < GOMOKU_SIZE and board[rr][cc] == 0:
                            cands.add((rr, cc))
    if not cands:
        cands.add((GOMOKU_SIZE // 2, GOMOKU_SIZE // 2))
    return list(cands)


def _gomoku_ordered(board, side, opp):
    cands = _gomoku_candidates(board)
    scored = []
    for r, c in cands:
        board[r][c] = side
        attack = _gomoku_score(board, side)
        board[r][c] = opp
        defend = _gomoku_score(board, opp)
        board[r][c] = 0
        scored.append((attack * 1.1 + defend, r, c))
    scored.sort(reverse=True)
    return [(r, c) for _, r, c in scored]


def _gomoku_search(board, side, opp, depth, alpha, beta, root_side):
    if depth == 0:
        return _gomoku_score(board, root_side) - _gomoku_score(board, 3 - root_side)
    moves = _gomoku_ordered(board, side, opp)[:10]
    best = -10**9
    for r, c in moves:
        board[r][c] = side
        if _gomoku_win(board, r, c, side):
            board[r][c] = 0
            return 10**8 - depth
        val = -_gomoku_search(board, opp, side, depth - 1, -beta, -alpha, root_side)
        board[r][c] = 0
        if val > best:
            best = val
        alpha = max(alpha, val)
        if alpha >= beta:
            break
    return best


def gomoku_ai(state, side, stars=30, opening_book=None):
    board = state["board"]
    opp = 3 - side
    empty = sum(row.count(0) for row in board)
    if empty == GOMOKU_SIZE * GOMOKU_SIZE:
        return [GOMOKU_SIZE // 2, GOMOKU_SIZE // 2]
    depth = 1 if stars < 40 else (2 if stars < 75 else 2)
    noise = max(0.0, (60 - stars) / 60.0)
    moves = _gomoku_ordered(board, side, opp)
    if opening_book:
        for (r, c) in moves:
            key = f"{side}:{r},{c}"
            stat = opening_book.get(key)
            if stat and stat[0] >= 3 and stat[1] / max(1, stat[0]) > 0.55:
                return [r, c]
    best_val, best_moves = -10**9, []
    limit = 12 if depth >= 2 else 6
    for r, c in moves[:limit]:
        board[r][c] = side
        if _gomoku_win(board, r, c, side):
            board[r][c] = 0
            return [r, c]
        val = -_gomoku_search(board, opp, side, depth, -10**9, 10**9, side)
        board[r][c] = 0
        val += random.random() * noise * 20000
        if val > best_val + 1e-9:
            best_val, best_moves = val, [(r, c)]
        elif abs(val - best_val) <= 1e-9:
            best_moves.append((r, c))
    r, c = random.choice(best_moves)
    return [r, c]


def gomoku_legal(state, side):
    board = state["board"]
    return [[r, c] for r in range(GOMOKU_SIZE) for c in range(GOMOKU_SIZE) if board[r][c] == 0]


# ---------------- TicTacToe ----------------

def new_tictactoe():
    return {"board": [0] * 9, "last": None, "moves": 0}


_TTT_LINES = [(0, 1, 2), (3, 4, 5), (6, 7, 8), (0, 3, 6), (1, 4, 7), (2, 5, 8), (0, 4, 8), (2, 4, 6)]


def _ttt_winner(board):
    for a, b, c in _TTT_LINES:
        if board[a] and board[a] == board[b] == board[c]:
            return board[a]
    return 0


def tictactoe_move(state, move, side):
    try:
        idx = int(move)
    except Exception:
        return False, state, None
    board = state["board"]
    if not (0 <= idx < 9) or board[idx] != 0:
        return False, state, None
    board[idx] = side
    state["last"] = idx
    state["moves"] = state.get("moves", 0) + 1
    w = _ttt_winner(board)
    if w:
        return True, state, f"win:{w}"
    if state["moves"] >= 9:
        return True, state, "draw"
    return True, state, None


def _ttt_minimax(board, side, me, depth=0):
    w = _ttt_winner(board)
    if w:
        return (10 - depth) if w == me else (depth - 10)
    if 0 not in board:
        return 0
    scores = []
    for i in range(9):
        if board[i] == 0:
            board[i] = side
            scores.append(_ttt_minimax(board, 3 - side, me, depth + 1))
            board[i] = 0
    return max(scores) if side == me else min(scores)


def tictactoe_ai(state, side, stars=30):
    board = state["board"]
    empties = [i for i in range(9) if board[i] == 0]
    if not empties:
        return None
    if stars < 20:
        return random.choice(empties)
    best, best_i = -100, None
    for i in empties:
        board[i] = side
        val = _ttt_minimax(board, 3 - side, side)
        board[i] = 0
        if val > best:
            best, best_i = val, i
    if best_i is None:
        best_i = random.choice(empties)
    return best_i


def tictactoe_legal(state, side):
    return [i for i in range(9) if state["board"][i] == 0]


# ---------------- Xiangqi ----------------
# board 10 rows x 9 cols. Red pieces uppercase letters: K A E H R C P, black lowercase.

XQ_INIT = [
    list("rheakaehr"),
    [""] * 9,
    ["", "c", "", "", "", "", "", "c", ""],
    ["p", "", "p", "", "p", "", "p", "", "p"],
    [""] * 9,
    [""] * 9,
    ["P", "", "P", "", "P", "", "P", "", "P"],
    ["", "C", "", "", "", "", "", "C", ""],
    [""] * 9,
    list("RHEAKAEHR"),
]

XQ_VALUES = {"K": 10000, "R": 900, "C": 450, "H": 400, "E": 200, "A": 200, "P": 100}


def new_xiangqi():
    return {"board": [row[:] for row in XQ_INIT], "last": None, "moves": 0}


def _xq_side(p):
    if not p:
        return 0
    return 1 if p.isupper() else 2


def _xq_in_palace(r, c, side):
    if not (3 <= c <= 5):
        return False
    return 7 <= r <= 9 if side == 1 else 0 <= r <= 2


def _xq_gen(board, side):
    moves = []
    for r in range(10):
        for c in range(9):
            p = board[r][c]
            if not p or _xq_side(p) != side:
                continue
            up = p.upper()
            if up == "K":
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    rr, cc = r + dr, c + dc
                    if _xq_in_palace(rr, cc, side) and _xq_side(board[rr][cc]) != side:
                        moves.append((r, c, rr, cc))
            elif up == "A":
                for dr, dc in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
                    rr, cc = r + dr, c + dc
                    if _xq_in_palace(rr, cc, side) and _xq_side(board[rr][cc]) != side:
                        moves.append((r, c, rr, cc))
            elif up == "E":
                for dr, dc in ((2, 2), (2, -2), (-2, 2), (-2, -2)):
                    rr, cc = r + dr, c + dc
                    mr, mc = r + dr // 2, c + dc // 2
                    if not (0 <= rr < 10 and 0 <= cc < 9) or board[mr][mc]:
                        continue
                    if side == 1 and rr < 5:
                        continue
                    if side == 2 and rr > 4:
                        continue
                    if _xq_side(board[rr][cc]) != side:
                        moves.append((r, c, rr, cc))
            elif up == "H":
                for dr, dc, lr, lc in ((2, 1, 1, 0), (2, -1, 1, 0), (-2, 1, -1, 0), (-2, -1, -1, 0),
                                       (1, 2, 0, 1), (-1, 2, 0, 1), (1, -2, 0, -1), (-1, -2, 0, -1)):
                    rr, cc = r + dr, c + dc
                    if not (0 <= rr < 10 and 0 <= cc < 9):
                        continue
                    if board[r + lr][c + lc]:
                        continue
                    if _xq_side(board[rr][cc]) != side:
                        moves.append((r, c, rr, cc))
            elif up == "R":
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    rr, cc = r + dr, c + dc
                    while 0 <= rr < 10 and 0 <= cc < 9:
                        if board[rr][cc]:
                            if _xq_side(board[rr][cc]) != side:
                                moves.append((r, c, rr, cc))
                            break
                        moves.append((r, c, rr, cc))
                        rr += dr
                        cc += dc
            elif up == "C":
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    rr, cc = r + dr, c + dc
                    jumped = False
                    while 0 <= rr < 10 and 0 <= cc < 9:
                        target = board[rr][cc]
                        if not jumped:
                            if target:
                                jumped = True
                            else:
                                moves.append((r, c, rr, cc))
                        else:
                            if target:
                                if _xq_side(target) != side:
                                    moves.append((r, c, rr, cc))
                                break
                        rr += dr
                        cc += dc
            elif up == "P":
                forward = -1 if side == 1 else 1
                rr = r + forward
                if 0 <= rr < 10 and _xq_side(board[rr][c]) != side:
                    moves.append((r, c, rr, c))
                crossed = r <= 4 if side == 1 else r >= 5
                if crossed:
                    for dc in (1, -1):
                        cc = c + dc
                        if 0 <= cc < 9 and _xq_side(board[r][cc]) != side:
                            moves.append((r, c, r, cc))
    return moves


def _xq_find_king(board, side):
    target = "K" if side == 1 else "k"
    for r in range(10):
        for c in range(9):
            if board[r][c] == target:
                return r, c
    return None


def _xq_in_check(board, side):
    king = _xq_find_king(board, side)
    if not king:
        return True
    kr, kc = king
    for r, c, rr, cc in _xq_gen(board, 3 - side):
        if (rr, cc) == (kr, kc):
            return True
    opp_king = _xq_find_king(board, 3 - side)
    if opp_king and opp_king[1] == kc:
        r1, r2 = sorted((kr, opp_king[0]))
        if all(not board[r][kc] for r in range(r1 + 1, r2)):
            return True
    return False


def _xq_apply(board, mv):
    r, c, rr, cc = mv
    captured = board[rr][cc]
    board[rr][cc] = board[r][c]
    board[r][c] = ""
    return captured


def _xq_undo(board, mv, captured):
    r, c, rr, cc = mv
    board[r][c] = board[rr][cc]
    board[rr][cc] = captured


def xiangqi_move(state, move, side):
    try:
        mv = tuple(int(x) for x in move)
    except Exception:
        return False, state, None
    if len(mv) != 4:
        return False, state, None
    legal = _xq_gen(state["board"], side)
    if mv not in legal:
        return False, state, None
    board = state["board"]
    board = [row[:] for row in board]
    captured = _xq_apply(board, mv)
    if _xq_in_check(board, side):
        return False, state, None
    state["board"] = board
    state["last"] = list(mv)
    state["moves"] = state.get("moves", 0) + 1
    opp = 3 - side
    if captured.upper() == "K":
        return True, state, f"win:{side}"
    if _xq_in_check(board, opp):
        opp_moves = [m for m in _xq_gen(board, opp) if not _xq_after_check(board, m, opp)]
        if not opp_moves:
            return True, state, f"win:{side}"
    return True, state, None


def _xq_after_check(board, mv, side):
    b = [row[:] for row in board]
    _xq_apply(b, mv)
    return _xq_in_check(b, side)


def _xq_eval(board, side):
    total = 0
    for r in range(10):
        for c in range(9):
            p = board[r][c]
            if not p:
                continue
            val = XQ_VALUES.get(p.upper(), 0)
            total += val if _xq_side(p) == side else -val
    return total


def _xq_search(board, side, depth, alpha, beta, root):
    if depth == 0:
        return _xq_eval(board, root)
    moves = _xq_gen(board, side)
    moves.sort(key=lambda m: XQ_VALUES.get((board[m[2]][m[3]] or " ").upper(), 0), reverse=True)
    best = -10**9
    for mv in moves:
        captured = _xq_apply(board, mv)
        if _xq_in_check(board, side):
            _xq_undo(board, mv, captured)
            continue
        val = -_xq_search(board, 3 - side, depth - 1, -beta, -alpha, root)
        _xq_undo(board, mv, captured)
        if val > best:
            best = val
        alpha = max(alpha, val)
        if alpha >= beta:
            break
    return best if best > -10**9 else -10**6


def xiangqi_ai(state, side, stars=30):
    board = [row[:] for row in state["board"]]
    moves = _xq_gen(board, side)
    if not moves:
        return None
    import random as _r

    scored = []
    for mv in moves:
        captured = _xq_apply(board, mv)
        if _xq_in_check(board, side):
            _xq_undo(board, mv, captured)
            continue
        gain = XQ_VALUES.get(captured.upper(), 0) if captured else 0
        _xq_undo(board, mv, captured)
        scored.append((gain, mv))
    scored.sort(key=lambda x: x[0], reverse=True)
    depth = 1 if stars < 50 else 2
    if stars >= 85:
        depth = 2
    noise = max(0.0, (70 - stars) / 70.0)
    best_val, best = -10**9, None
    pool = scored[:14] if depth >= 2 else scored[:8]
    for gain, mv in pool:
        captured = _xq_apply(board, mv)
        if _xq_in_check(board, side):
            _xq_undo(board, mv, captured)
            continue
        val = -_xq_search(board, 3 - side, depth, -10**9, 10**9, side)
        _xq_undo(board, mv, captured)
        val += gain + random.random() * noise * 300
        if val > best_val:
            best_val, best = val, mv
    return list(best or moves[0])


def xiangqi_legal(state, side):
    board = state["board"]
    out = []
    for mv in _xq_gen(board, side):
        b = [row[:] for row in board]
        _xq_apply(b, mv)
        if not _xq_in_check(b, side):
            out.append(list(mv))
    return out


# ---------------- Doubeast (Jungle chess) ----------------
# 7 cols x 9 rows. Black (2) top, Red (1) bottom.
# pieces: rank values. r/R rat=1, cat=2, dog=3, wolf=4, leopard=5, tiger=6, lion=7, elephant=8
DB_INIT = [
    ["b_lion", "", "", "", "", "", "b_tiger"],
    ["", "b_dog", "", "", "", "b_cat", ""],
    ["b_rat", "", "b_leopard", "", "b_wolf", "", "b_elephant"],
    ["", "", "", "", "", "", ""],
    ["", "", "", "", "", "", ""],
    ["", "", "", "", "", "", ""],
    ["r_elephant", "", "r_wolf", "", "r_leopard", "", "r_rat"],
    ["", "r_cat", "", "", "", "r_dog", ""],
    ["r_tiger", "", "", "", "", "", "r_lion"],
]
DB_RANK = {"rat": 1, "cat": 2, "dog": 3, "wolf": 4, "leopard": 5, "tiger": 6, "lion": 7, "elephant": 8}
DB_RIVERS = {(3, 1), (3, 2), (3, 4), (3, 5), (4, 1), (4, 2), (4, 4), (4, 5), (5, 1), (5, 2), (5, 4), (5, 5)}
DB_TRAPS = {(0, 2), (0, 4), (1, 3), (8, 2), (8, 4), (7, 3)}
DB_DENS = {(0, 3): 2, (8, 3): 1}


def new_doubeast():
    return {"board": [row[:] for row in DB_INIT], "last": None, "moves": 0}


def _db_side(p):
    return 1 if p.startswith("r_") else 2


def _db_kind(p):
    return p.split("_", 1)[1]


def _db_can_capture(attacker, defender, atk_r, atk_c, def_r, def_c):
    if not attacker or not defender or _db_side(attacker) == _db_side(defender):
        return False
    ak, dk = _db_kind(attacker), _db_kind(defender)
    arank, drank = DB_RANK[ak], DB_RANK[dk]
    if (def_r, def_c) in DB_TRAPS:
        trap_owner = 2 if def_r <= 1 else 1
        if _db_side(defender) != trap_owner:
            return True
    if ak == "rat" and dk == "elephant":
        return True
    if ak == "elephant" and dk == "rat":
        return False
    in_water_atk = (atk_r, atk_c) in DB_RIVERS
    in_water_def = (def_r, def_c) in DB_RIVERS
    if in_water_atk and not in_water_def:
        return False
    if in_water_def and not in_water_atk:
        return False
    return arank >= drank


def _db_moves_from(board, r, c):
    p = board[r][c]
    if not p:
        return []
    side = _db_side(p)
    kind = _db_kind(p)
    out = []
    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        rr, cc = r + dr, c + dc
        if not (0 <= rr < 9 and 0 <= cc < 7):
            continue
        target = board[rr][cc]
        if target and _db_side(target) == side:
            continue
        in_water_atk = (r, c) in DB_RIVERS
        in_water_dst = (rr, cc) in DB_RIVERS
        if in_water_dst and kind not in ("rat", "lion", "tiger"):
            continue
        if _db_can_capture(p, target, r, c, rr, cc):
            out.append((r, c, rr, cc))
        elif not target:
            out.append((r, c, rr, cc))
    if kind in ("lion", "tiger"):
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            rr, cc = r + dr, c + dc
            steps = 0
            blocked = False
            while 0 <= rr < 9 and 0 <= cc < 7 and (rr, cc) in DB_RIVERS:
                if board[rr][cc] == "":
                    pass
                elif _db_kind(board[rr][cc]) == "rat":
                    blocked = True
                    break
                else:
                    blocked = True
                    break
                rr += dr
                cc += dc
                steps += 1
            if steps and not blocked and 0 <= rr < 9 and 0 <= cc < 7:
                target = board[rr][cc]
                if not target:
                    out.append((r, c, rr, cc))
                elif _db_can_capture(p, target, r, c, rr, cc):
                    out.append((r, c, rr, cc))
    return out


def _db_gen(board, side):
    moves = []
    for r in range(9):
        for c in range(7):
            if board[r][c] and _db_side(board[r][c]) == side:
                moves.extend(_db_moves_from(board, r, c))
    return moves


def doubeast_move(state, move, side):
    try:
        mv = tuple(int(x) for x in move)
    except Exception:
        return False, state, None
    board = [row[:] for row in state["board"]]
    if mv not in _db_gen(board, side):
        return False, state, None
    r, c, rr, cc = mv
    target = board[rr][cc]
    board[rr][cc] = board[r][c]
    board[r][c] = ""
    state["board"] = board
    state["last"] = list(mv)
    state["moves"] = state.get("moves", 0) + 1
    if DB_DENS.get((rr, cc)) == 3 - side:
        return True, state, f"win:{side}"
    if target and _db_kind(target) == "lion" and _db_side(target) != side:
        pass
    opp = 3 - side
    if not any(board[r2][c2] and _db_side(board[r2][c2]) == opp for r2 in range(9) for c2 in range(7)):
        return True, state, f"win:{side}"
    if not _db_gen(board, opp):
        return True, state, f"win:{side}"
    return True, state, None


def _db_eval(board, side):
    score = 0
    for r in range(9):
        for c in range(7):
            p = board[r][c]
            if not p:
                continue
            s = _db_side(p)
            val = DB_RANK[_db_kind(p)] * 100
            if s == side:
                score += val + (8 - r if side == 1 else r)
            else:
                score -= val + (r if side == 1 else 8 - r)
    return score


def doubeast_ai(state, side, stars=30):
    board = [row[:] for row in state["board"]]
    moves = _db_gen(board, side)
    if not moves:
        return None
    depth = 1 if stars < 55 else 2
    noise = max(0.0, (60 - stars) / 60.0)
    best_val, best = -10**9, None
    for mv in moves:
        r, c, rr, cc = mv
        target = board[rr][cc]
        board[rr][cc] = board[r][c]
        board[r][c] = ""
        if DB_DENS.get((rr, cc)) == 3 - side:
            board[r][c] = board[rr][cc]
            board[rr][cc] = target
            return list(mv)
        val = -_db_eval(board, 3 - side)
        board[r][c] = board[rr][cc]
        board[rr][cc] = target
        val += random.random() * noise * 60
        if val > best_val:
            best_val, best = val, mv
    return list(best or moves[0])


def doubeast_legal(state, side):
    return [list(m) for m in _db_gen(state["board"], side)]


# ---------------- Registry ----------------

GAMES = {
    "gomoku": {
        "key": "gomoku", "name": "五子棋", "max_players": 2, "available": True,
        "new": new_gomoku, "move": gomoku_move, "ai": gomoku_ai, "legal": gomoku_legal,
        "desc": "15路棋盘，五子连珠获胜",
    },
    "tictactoe": {
        "key": "tictactoe", "name": "井字棋", "max_players": 2, "available": True,
        "new": new_tictactoe, "move": tictactoe_move, "ai": tictactoe_ai, "legal": tictactoe_legal,
        "desc": "3x3经典井字棋",
    },
    "xiangqi": {
        "key": "xiangqi", "name": "中国象棋", "max_players": 2, "available": True,
        "new": new_xiangqi, "move": xiangqi_move, "ai": xiangqi_ai, "legal": xiangqi_legal,
        "desc": "完整中国象棋规则",
    },
    "doubeast": {
        "key": "doubeast", "name": "斗兽棋", "max_players": 2, "available": True,
        "new": new_doubeast, "move": doubeast_move, "ai": doubeast_ai, "legal": doubeast_legal,
        "desc": "经典斗兽棋，鼠可克象",
    },
    "go": {
        "key": "go", "name": "围棋", "max_players": 2, "available": False,
        "desc": "开发中",
    },
    "chess": {
        "key": "chess", "name": "国际象棋", "max_players": 2, "available": False,
        "desc": "开发中",
    },
    "junqi": {
        "key": "junqi", "name": "军棋", "max_players": 2, "available": False,
        "desc": "开发中",
    },
    "feixing": {
        "key": "feixing", "name": "飞行棋", "max_players": 4, "available": False,
        "desc": "开发中，支持4人",
    },
    "tiaoqi": {
        "key": "tiaoqi", "name": "跳棋", "max_players": 2, "available": False,
        "desc": "开发中",
    },
    "doudizhu": {
        "key": "doudizhu", "name": "斗地主", "max_players": 3, "available": False,
        "desc": "开发中",
    },
}


def game_meta():
    return [
        {k: v[k] for k in ("key", "name", "max_players", "available", "desc")}
        for v in GAMES.values()
    ]


RANK_NAMES = [
    "青铜", "白银", "黄金", "铂金", "钻石", "星耀",
    "大师", "宗师", "王者", "传奇", "荣耀", "巅峰",
]


def rank_label(division, stars):
    d = max(1, min(12, division))
    s = max(0, min(2, stars))
    return f"{RANK_NAMES[d - 1]}{'ⅠⅡⅢ'[s]}"


def apply_ranked_result(points, division, stars, won):
    """Returns (points, division, stars, delta). 100 points -> 1 star, 3 stars -> 1 division, 12 divisions max."""
    if won:
        delta = 22 + (division - 1) * 2
    else:
        delta = -(14 + (division - 1))
    points += delta
    while points >= 100:
        points -= 100
        stars += 1
        if stars >= 3:
            stars = 0
            if division < 12:
                division += 1
    while points < 0:
        if stars > 0:
            stars -= 1
            points += 100
        elif division > 1:
            division -= 1
            stars = 2
            points += 100
        else:
            points = 0
            break
    return points, division, stars, delta
